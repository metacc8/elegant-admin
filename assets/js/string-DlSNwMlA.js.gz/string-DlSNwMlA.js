function r(t=10){return Math.random().toString(36).substring(2,2+t)}function e(t){return t.charAt(0).toUpperCase()+t.slice(1)}export{e as c,r as g};
